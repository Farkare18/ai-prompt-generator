import { useState } from 'react';
import axios from 'axios';

function App() {
  const [prompt, setPrompt] = useState('');
  const [response, setResponse] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    const res = await axios.post(import.meta.env.VITE_API_URL + "/generate", { prompt });
    setResponse(res.data.result);
  };

  return (
    <div className="container">
      <h1>AI Prompt Generator</h1>
      <form onSubmit={handleSubmit}>
        <input type="text" value={prompt} onChange={(e) => setPrompt(e.target.value)} />
        <button type="submit">Submit</button>
      </form>
      <p><strong>Response:</strong> {response}</p>
    </div>
  );
}

export default App;
